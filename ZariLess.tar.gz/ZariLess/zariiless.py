from PyQt5.QtCore import QUrl, Qt
from PyQt5.QtGui import QPalette, QColor, QIcon, QPixmap
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtWidgets import QMainWindow, QApplication, QToolBar, QAction, QLineEdit, QTabWidget
import sys
import time

tempo_inicial = time.time()

Home = 'http://inckteste.great-site.net/startpage_zariiless/start.html'
nome_browser = "Zariless"


class MainWindow(QMainWindow):
    def __init__(self, *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)

        self.setWindowTitle(f"{nome_browser} - Browser")
        self.setWindowIcon(QIcon('Images/Browser/Zariless_icon.png'))

        self.tabs = QTabWidget()
        self.tabs.tabBar().setStyleSheet(
            "color: black;border-radius:1px;background-color: rgb(35,35,35);")
        self.tabs.setDocumentMode(True)
        self.tabs.tabBarDoubleClicked.connect(self.tab_open_doubleclick)
        self.tabs.currentChanged.connect(self.current_tab_changed)
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_current_tab)
        self.setCentralWidget(self.tabs)

        navtb = QToolBar('Navigation')
        navtb.setMovable(False)
        navtb.setStyleSheet(
            '''border:1px solid rgb(42,42,42);
               border-radius: 1px;
               padding: 2px 5px 2px;
               margin: 0px 2px 0px;
            ''')

        icotb = QToolBar('Communication')
        icotb.setMovable(True)
        icotb.setStyleSheet(
            '''border: 0px;
               padding: 2px 5px 2px;
               margin: 10px 0px 10px;
            ''')

        self.addToolBar(Qt.TopToolBarArea, navtb)
        self.addToolBar(Qt.LeftToolBarArea, icotb)

        home_icon = QIcon()
        home_icon.addPixmap(QPixmap("Images/Communication/Home.png"))
        home_btn = QAction(self)
        home_btn.triggered.connect(self.navigate_home)
        home_btn.setIcon(home_icon)
        icotb.addAction(home_btn)

        wtz_icon_icone = QIcon()
        wtz_icon_icone.addPixmap(QPixmap("Images/Communication/whatsapp.png"))
        wtz_icon = QAction(self)
        wtz_icon.setIcon(wtz_icon_icone)
        wtz_icon.triggered.connect(self.whatsapp)
        icotb.addAction(wtz_icon)

        face_icon_icone = QIcon()
        face_icon_icone.addPixmap(QPixmap("Images/Communication/facebook.png"))
        face_icon = QAction(self)
        face_icon.setIcon(face_icon_icone)
        face_icon.triggered.connect(self.facebook)
        icotb.addAction(face_icon)

        dc_icon_icone = QIcon()
        dc_icon_icone.addPixmap(QPixmap("Images/Communication/discord.png"))
        dc_icon = QAction(self)
        dc_icon.setIcon(dc_icon_icone)
        dc_icon.triggered.connect(self.discord)
        icotb.addAction(dc_icon)

        git_icon_icone = QIcon()
        git_icon_icone.addPixmap(QPixmap("Images/Communication/github.png"))
        git_icon = QAction(self)
        git_icon.setIcon(git_icon_icone)
        git_icon.triggered.connect(self.github)
        icotb.addAction(git_icon)

        twitter_icon_icone = QIcon()
        twitter_icon_icone.addPixmap(
            QPixmap("Images/Communication/twitter.png"))
        twitter_icon = QAction(self)
        twitter_icon.setIcon(twitter_icon_icone)
        twitter_icon.triggered.connect(self.twitter)
        icotb.addAction(twitter_icon)

        spotify_icon_icone = QIcon()
        spotify_icon_icone.addPixmap(
            QPixmap("Images/Communication/spotify.png"))
        spotify_icon = QAction(self)
        spotify_icon.setIcon(spotify_icon_icone)
        spotify_icon.triggered.connect(self.spotify)
        icotb.addAction(spotify_icon)

        reddit_icon_icone = QIcon()
        reddit_icon_icone.addPixmap(QPixmap("Images/Communication/reddit.png"))
        reddit_icon = QAction(self)
        reddit_icon.setIcon(reddit_icon_icone)
        reddit_icon.triggered.connect(self.reddit)
        icotb.addAction(reddit_icon)

        tele_icon_icone = QIcon()
        tele_icon_icone.addPixmap(QPixmap("Images/Communication/telegram.png"))
        tele_icon = QAction(self)
        tele_icon.setIcon(tele_icon_icone)
        tele_icon.triggered.connect(self.telegram)
        icotb.addAction(tele_icon)

        yt_icon_icone = QIcon()
        yt_icon_icone.addPixmap(QPixmap("Images/Communication/youtube.png"))
        yt_icon = QAction(self)
        yt_icon.setIcon(yt_icon_icone)
        yt_icon.triggered.connect(self.youtube)
        icotb.addAction(yt_icon)

        gl_icon_icone = QIcon()
        gl_icon_icone.addPixmap(QPixmap("Images/Communication/google.png"))
        gl_icon = QAction(self)
        gl_icon.setIcon(gl_icon_icone)
        gl_icon.triggered.connect(self.google)
        icotb.addAction(gl_icon)

        back_icon = QIcon()
        back_icon.addPixmap(QPixmap("Images/Navigation/Back.png"))
        back_btn = QAction(self)
        back_btn.triggered.connect(self.back_br)
        back_btn.setIcon(back_icon)
        navtb.addAction(back_btn)

        next_icon = QIcon()
        next_icon.addPixmap(QPixmap("Images/Navigation/Forward.png"))
        next_btn = QAction(self)
        next_btn.triggered.connect(self.forward_br)
        next_btn.setIcon(next_icon)
        navtb.addAction(next_btn)

        reload_icon = QIcon()
        reload_icon.addPixmap(QPixmap("Images/Navigation/Refresh.png"))
        reload_btn = QAction(self)
        reload_btn.triggered.connect(self.reload_br)
        reload_btn.setIcon(reload_icon)
        navtb.addAction(reload_btn)

        navtb.addSeparator()
        self.urlbar = QLineEdit()
        self.urlbar.returnPressed.connect(self.navigate_to_url)
        navtb.addWidget(self.urlbar)

        self.add_new_tab(QUrl(Home), f'New tab')

        self.show()

    def add_new_tab(self, qurl=None, label="Blank"):
        if qurl is None:
            qurl = QUrl(Home)
        browser = QWebEngineView()
        browser.setUrl(qurl)

        i = self.tabs.addTab(browser, label)
        self.tabs.setCurrentIndex(i)
        browser.urlChanged.connect(lambda qurl, browser=browser:
                                   self.update_urlbar(browser))
        browser.loadFinished.connect(lambda _, i=i, browser=browser:
                                     self.tabs.setTabText(i, browser.page().title()))

    def tab_open_doubleclick(self, i):
        if i == -1:
            self.add_new_tab()

    def close_current_tab(self, i):
        if self.tabs.count() < 2:
            return
        self.tabs.removeTab(i)

    def current_tab_changed(self, i):
        self.update_urlbar(self.tabs.currentWidget().url())

    def reload_br(self):
        qt = self.tabs.currentWidget()
        qt.reload()

    def back_br(self):
        qt = self.tabs.currentWidget()
        qt.back()

    def forward_br(self):
        qt = self.tabs.currentWidget()
        qt.forward()

    def youtube(self): self.add_new_tab(
        QUrl("https://www.youtube.com/"), f'{self.tabs.currentWidget().page().title()}')
    
    def facebook(self): self.add_new_tab(
        QUrl("https://www.facebook.com/"), f'{self.tabs.currentWidget().page().title()}')

    def spotify(self): self.add_new_tab(
        QUrl("https://open.spotify.com/"), f'{self.tabs.currentWidget().page().title()}')

    def telegram(self): self.add_new_tab(QUrl(
        "https://web.telegram.org/k/"), f'{self.tabs.currentWidget().page().title()}')

    def github(self): self.add_new_tab(QUrl("https://github.com/"),
                                       f'{self.tabs.currentWidget().page().title()}')

    def reddit(self): self.add_new_tab(QUrl("https://www.reddit.com/"),
                                       f'{self.tabs.currentWidget().page().title()}')

    def twitter(self): self.add_new_tab(QUrl(
        "https://mobile.twitter.com/explore"), f'{self.tabs.currentWidget().page().title()}')

    def twitch(self): self.add_new_tab(QUrl("https://www.twitch.tv/"),
                                       f'{self.tabs.currentWidget().page().title()}')

    def discord(self): self.add_new_tab(QUrl("https://discord.com/"),
                                        f'{self.tabs.currentWidget().page().title()}')

    def whatsapp(self): self.add_new_tab(QUrl(
        "https://www.whatsapp.com/?lang=pt_br"), f'{self.tabs.currentWidget().page().title()}')

    def google(self): self.add_new_tab(QUrl("https://www.google.com/"),
                                       f'{self.tabs.currentWidget().page().title()}')

    def navigate_home(self):self.tabs.currentWidget().setUrl(QUrl(Home));

    def navigate_to_url(self):
        q = QUrl(self.urlbar.text())
        if q.scheme() == '':
            q.setScheme('http')
        self.tabs.currentWidget().setUrl(q)

    def update_urlbar(self, q, browser=None):
        if browser != self.tabs.currentWidget():
            return
        self.urlbar.setText(q.toString())
        self.urlbar.setCursorPosition(0)


app = QApplication(sys.argv)
app.setApplicationName(f'{nome_browser}')
palette = QPalette()
palette.setColor(QPalette.Window, QColor(49, 49, 49))
palette.setColor(QPalette.WindowText, Qt.white)
palette.setColor(QPalette.Base, QColor(75, 75, 75))
palette.setColor(QPalette.AlternateBase, QColor(49, 49, 49))
palette.setColor(QPalette.ToolTipBase, Qt.black)
palette.setColor(QPalette.ToolTipText, Qt.white)
palette.setColor(QPalette.Text, Qt.gray)
palette.setColor(QPalette.Button, QColor(72, 26, 81))
palette.setColor(QPalette.ButtonText, Qt.white)
palette.setColor(QPalette.BrightText, Qt.red)
palette.setColor(QPalette.Link, QColor(42, 130, 218))
palette.setColor(QPalette.Highlight, QColor(42, 130, 218))
palette.setColor(QPalette.HighlightedText, Qt.black)
app.setPalette(palette)
window = MainWindow()
print(f'Tempo de carregamento: {time.time() - tempo_inicial} segundos.')
app.exec_()
